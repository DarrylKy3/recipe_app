package com.myrecipeapp

import android.os.Bundle

class explorepage  {

    private fun  onCreate(savedInstanceState: Bundle?) {
        this.onCreate(savedInstanceState)
        setContentView(R.layout.explorepagelayout)
    }

    private fun setContentView(explorepagelayout: Any) {

    }
}



